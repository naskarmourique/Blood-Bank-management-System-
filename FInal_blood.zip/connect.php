<?php

    $conn = mysqli_connect("localhost","root","","blood");

    // if($conn)
    // {
    //     echo "Connected to database";
    // }
    // else
    // {
    //     echo "Connection ERROR";
    // }

?>